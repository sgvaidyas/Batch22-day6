﻿using System;

namespace Batch22day6
{

    class Stacks
    {
        static void push(int[] a,ref int top)
        {
            if(top == a.Length-1)
                Console.WriteLine("Stack overflow");
            else
            {
                int ele;
                Console.WriteLine("Enter the element ");
                ele = int.Parse(Console.ReadLine());
                a[++top] = ele;
            }
        }

        static void pop(int[] a,ref int top)
        {
            if(top==-1)
                Console.WriteLine("stack underflow");
            else
            {
                Console.WriteLine("\n\ndeleting.... "+ a[top--]);
            }
        }
        static void display(int[] a,int top)
        {
            if(top==-1)
                Console.WriteLine("Stack is empty");
            else
            {
                Console.WriteLine("stack elements ");
                for(int i = top;i>=0;i--)
                    Console.WriteLine(a[i]);
            }
        }
        static void Main(string[] args)
        {
            int max = 5;
            int[] a = new int[max];
            int top = -1;
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1 PUSH 2 POP 3 DISPLAY 4 EXIT");
                int ch = int.Parse(Console.ReadLine());

                switch(ch)
                {
                    case 1: push(a,ref top);break;
                    case 2: pop(a, ref top);break;
                    case 3: display(a,top);break;
                    case 4: flag = false;break;
                    default: Console.WriteLine("invalid choice");break;
                }

            }
            
        }
    }
}
