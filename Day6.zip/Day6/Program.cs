﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day6
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[] { 11,22,3,11,22,3,4,7,3};

            Array.Sort(a);
            for(int i=0;i<a.Length;i++)
                Console.WriteLine(a[i]);
            int cnt, flag;
            Console.WriteLine("\n\nthe repeated elements are = ");

            for(int i=0;i<a.Length-1;i++)
            {
                cnt = 1;
                flag = 0;

                while(  i<a.Length-1 && a[i]==a[i+1])
                {
                    cnt++;
                    flag = 1;
                    i++;
                }
                if (flag == 1)     //if(flag==0) --> Prints the non repeated value
                    Console.WriteLine(a[i] + " : " + cnt);

            }

        }
    }
}
