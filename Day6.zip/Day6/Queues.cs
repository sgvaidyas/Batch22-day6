﻿using System;

namespace Batch22day6
{
    class Queues
    {
        static void enqueue(int[] a,ref int rear)
        {
            if (rear == a.Length - 1)
                Console.WriteLine("Queue overflow");
            else
            {
                int ele;
                Console.WriteLine("Enter the element ");
                ele = int.Parse(Console.ReadLine());
                a[++rear] = ele;
            }
        }

        static void dequeue(int[] a,ref int front,ref int rear)
        {
            if(front>rear)
            {
                Console.WriteLine("Queue underflow");
                front = 0;
                rear = -1;
            }
            else
            {
                Console.WriteLine("\n\n Deleting ......... {0} \n\n",a[front++]);
            }
        }
        static void display(int[] a, int front, int rear)
        {
            if (front > rear)
            {
                Console.WriteLine("Queue Empty");
            }
            else
            {
                Console.WriteLine("Queue elements are  = ");
                for (int i = front; i <= rear; i++)
                    Console.Write(a[i] + "\t");
                Console.WriteLine();
            }
        }
        static void Main(string[] args)
        {
            int max = 5;
            int[] a = new int[max];
            int rear = -1, front = 0;
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1 ENQUEUE 2 DEQUEUE 3 DISPLAY 4 EXIT");
                int ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1: enqueue(a, ref rear); break;
                    case 2: dequeue(a, ref front, ref rear); break;
                    case 3: display(a, front, rear); break;
                    case 4: flag = false; break;
                    default: Console.WriteLine("invalid choice"); break;
                }
            }
        }
    }
}
