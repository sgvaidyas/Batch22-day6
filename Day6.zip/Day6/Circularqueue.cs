﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day6
{
    class Circularqueue
    {
        static void enqueue(int[] a, ref int rear,ref int front)
        {
            int max = a.Length;
            if (rear-front == max - 1)
                Console.WriteLine("Queue overflow");
            else
            {
                int ele;
                Console.WriteLine("Enter the element ");
                ele = int.Parse(Console.ReadLine());
                ++rear;
                a[rear % max ] = ele;
            }
        }

        static void dequeue(int[] a, ref int front, ref int rear)
        {
            int max = a.Length;
            if (front > rear)
            {
                Console.WriteLine("Queue underflow");
                front = 0;
                rear = -1;
            }
            else
            {
                Console.WriteLine("\n\n Deleting ......... {0} \n\n", a[front%max]);
                front++;
            }
        }
        static void display(int[] a, int front, int rear)
        {
            int max = a.Length;
            if (front > rear)
            {
                Console.WriteLine("Queue Empty");
            }
            else
            {
                Console.WriteLine("Queue elements are  = ");
                for (int i = front; i <= rear; i++)
                    Console.Write(a[i%max] + "\t");
                Console.WriteLine();
            }
        }
        static void Main(string[] args)
        {
            int max = 5;
            int[] a = new int[max];
            int rear = -1, front = 0;
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1 ENQUEUE 2 DEQUEUE 3 DISPLAY 4 EXIT");
                int ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1: enqueue(a, ref rear,ref front); break;
                    case 2: dequeue(a, ref front, ref rear); break;
                    case 3: display(a, front, rear); break;
                    case 4: flag = false; break;
                    default: Console.WriteLine("invalid choice"); break;
                }
            }
        }
    }
}
